package com.example.projeto_androidstudio_twitter

import PostAdapter
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FeedActivity : AppCompatActivity() {

    private lateinit var generalRecyclerView: RecyclerView
    private lateinit var schoolRecyclerView: RecyclerView
    private lateinit var generalAdapter: PostAdapter
    private lateinit var schoolAdapter: PostAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        // Inicializar RecyclerViews
        generalRecyclerView = findViewById(R.id.generalPostsRecyclerView)
        schoolRecyclerView = findViewById(R.id.schoolPostsRecyclerView)

        // Configurar LayoutManager para ambos os RecyclerViews
        generalRecyclerView.layoutManager = LinearLayoutManager(this)
        schoolRecyclerView.layoutManager = LinearLayoutManager(this)

        // Dados simulados para posts gerais
        val generalPosts = listOf(
            Post("Título do Post 1", "Este é um post geral para o Politécnico."),
            Post("Título do Post 2", "Outro post importante para todos os alunos."),
            Post("Título do Post 3", "Informações gerais do Politécnico.")
        )

        // Dados simulados para posts das escolas
        val schoolPosts = listOf(
            Post("Evento da Escola de Gestão", "Participe no workshop de liderança."),
            Post("Aula Aberta de Tecnologia", "Venha assistir à aula de programação avançada.")
        )

        // Configurar adaptadores
        generalAdapter = PostAdapter(generalPosts)
        schoolAdapter = PostAdapter(schoolPosts)

        // Atribuir adaptadores às RecyclerViews
        generalRecyclerView.adapter = generalAdapter
        schoolRecyclerView.adapter = schoolAdapter
    }
}
