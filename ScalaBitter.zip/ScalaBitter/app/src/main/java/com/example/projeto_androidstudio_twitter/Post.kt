package com.example.projeto_androidstudio_twitter


data class Post(
    val title: String,
    val content: String
)
